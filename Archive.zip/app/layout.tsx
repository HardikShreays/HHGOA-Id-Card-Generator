import type { Metadata } from "next";
import "./globals.css";

// Using system fonts for now (no network fetch at build time). Swap in the
// official HH Goa 2026 event font via next/font/local once assets exist
// (plan §5 / §11).

export const metadata: Metadata = {
  title: "HH Goa 2026 — Frame Generator",
  description: "Make your HH Goa 2026 frame or builder ID card in seconds. No sign-up.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">{children}</body>
    </html>
  );
}
